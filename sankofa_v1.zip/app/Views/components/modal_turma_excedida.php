<div id="turma_excedida" class="modal modal-fixed-footer print">
    <div class="modal-content">
        <h5>Erro</h5>
        <p>Não foi possível realizar a matrícula pois a turma escolhida está completa. Verifique com o Coordenador a possibilidade de inserir o Aluno em outra turma.</p>
    </div>
    <div class="modal-footer">
        <a href="#" id="btn_docs" class="modal-close btn waves-effect waves-light green">Continuar</a>
    </div>
</div>